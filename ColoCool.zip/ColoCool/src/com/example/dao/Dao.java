package com.example.dao;

import com.example.model.*;


import java.util.List;

public interface Dao {
	
	public List<Depense> listerDepense();
	

}
